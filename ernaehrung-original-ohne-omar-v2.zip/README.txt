Ernährung und Leben - 3D presentation website

HOW TO USE
1. Unzip this folder.
2. Double-click index.html (opens in Chrome or Edge). No internet is needed.
3. Press F for fullscreen. Arrow keys / Space = next and previous slide. Keys 1-9 = jump to a slide.
4. Click any photo (or press Z) to show it full screen. Click again or press any key to close.

HOW TO PUT IT ON GITHUB
Upload index.html to your repository (Add file > Upload files), commit, then turn on
Settings > Pages > Branch: main, folder: / (root).

HOW TO CHANGE NAMES OR DATE
Open index.html in a text editor, press Ctrl+F and search for "Omar Al Sharari", "Aya", "Chaimae" or "19.10.2026".
Change only the text. Do not edit the long blocks that start with "data:image" or "base64".
